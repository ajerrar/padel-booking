﻿import { Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { ReservationService } from '../../services/reservation-service';
import { UserService } from '../../services/user-service';

@Component({
  selector: 'app-payment-success',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './payment-success.html',
  styleUrls: ['./payment-success.css'],
})
export class PaymentSuccess {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private reservationService = inject(ReservationService);
  private userService = inject(UserService);

  me = this.userService.currentUser;

  clubName = signal<string>('—');
  courtName = signal<string>('—');
  time = signal<string>('—');
  total = signal<number>(0);

  // ✅ nouveaux champs pour admin
  date = signal<string>('');      // "YYYY-MM-DD"
  siteName = signal<string>('');  // "Waterloo"

  private created = signal(false);

  reference = computed(() => {
    const t = this.time();
    return `PADEL-${t.replace(':', '')}-${Math.floor(Math.random() * 9000 + 1000)}`;
  });

  constructor() {
    this.route.queryParamMap.subscribe(p => {
      this.clubName.set(p.get('clubName') ?? '—');
      this.courtName.set(p.get('courtName') ?? '—');
      this.time.set(p.get('time') ?? '—');
      this.total.set(Number(p.get('total') ?? 0));

      // ✅ récupère depuis query params si tu les passes
      this.date.set(p.get('date') ?? '');
      this.siteName.set(p.get('siteName') ?? '');

      this.createReservationOnce();
    });
  }

  private createReservationOnce() {
    if (this.created()) return;

    const u = this.me();
    if (!u) {
      this.router.navigate(['/login'], {replaceUrl: true});
      return;
    }

    if (this.clubName() === '—' || this.courtName() === '—' || this.time() === '—') return;
    try {
      this.reservationService.add({
        userMatricule: u.matricule,
        clubName: this.clubName(),
        courtName: this.courtName(),
        time: this.time(),
        total: this.total(),
        date: this.date(),
        siteName: this.siteName(),
      });
      this.created.set(true);
    } catch (e: any) {
      alert(e?.message ?? 'Impossible de créer la réservation');
      this.router.navigate(['/home']);
      return;
    }
  }

  goHome() {
    this.router.navigate(['/home']);
  }

  goMyReservations() {
    this.router.navigate(['/my-reservations']);
  }

  goBackToClub() {
    this.router.navigate(['/clubs']);
  }
}
