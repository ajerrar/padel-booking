import { Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { UserService } from "../../services/user-service";

@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './payment.html',
  styleUrls: ['./payment.css'],
})
export class Payment {
  private fb = inject(FormBuilder);
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private userService = inject(UserService);

  submitted = signal(false);

  // ✅ query params depuis Reservation
  clubName = computed(() => this.route.snapshot.queryParamMap.get('clubName') ?? '—');
  courtName = computed(() => this.route.snapshot.queryParamMap.get('courtName') ?? '—');
  time = computed(() => this.route.snapshot.queryParamMap.get('time') ?? '—');
  total = computed(() => Number(this.route.snapshot.queryParamMap.get('total') ?? 0));

  form = this.fb.nonNullable.group({
    matricule: [{ value: '', disabled: true }], // readonly
    firstName: ['', [Validators.required]],
    lastName: ['', [Validators.required]],
    email: ['', [Validators.required, Validators.email]],
    phone: ['', [Validators.required]],
    city: ['', [Validators.required]],
    level: ['', [Validators.required]],

    // Champs de paiement
    cardHolder: ['', [Validators.required, Validators.minLength(2)]],
    cardNumber: ['', [Validators.required, Validators.pattern(/^\d{16}$/)]],
    exp: ['', [Validators.required, Validators.pattern(/^\d{2}\/\d{2}$/)]],
    cvc: ['', [Validators.required, Validators.pattern(/^\d{3}$/)]],
  });

  constructor() {
    // ✅ préremplir depuis le user connecté
    const me = this.userService.currentUser();
    if (me) {
      this.form.patchValue({
        matricule: me.matricule,
        firstName: me.firstName,
        lastName: me.lastName,
        email: me.email,
        phone: me.phone ?? '',
        city: me.city,
        level: me.level,
      });
    }
  }

  submitPayment() {
    this.submitted.set(true);

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }


    this.router.navigate(['/payment-success'], {
      queryParams: {
        clubName: this.clubName?.() ?? this.clubName,
        courtName: this.courtName?.() ?? this.courtName,
        time: this.time?.() ?? this.time,
        total: this.total?.() ?? this.total,
      },
    });
  }

  back() {
    this.router.navigate(['/reservation'], { queryParamsHandling: 'preserve' });
  }
}
