import { Injectable } from '@angular/core';
import { ReservationModel } from '../models/reservation.model';
import { UserService } from './user-service';

const KEY = 'pb_reservations';

@Injectable({ providedIn: 'root' })
export class ReservationService {
  constructor(private userService: UserService) {}

  list(): ReservationModel[] {
    return this.read();
  }

  listByUser(matricule: string): ReservationModel[] {
    return this.read().filter(r => r.userMatricule === matricule);
  }

  add(data: Omit<ReservationModel, 'id' | 'createdAt' | 'status'>): ReservationModel {
    // ✅ SGBD: validations (catégorie + pénalité + fenêtre)
    this.assertCanBook(data.userMatricule, data.date);

    const item: ReservationModel = {
      id: `${Date.now()}-${Math.floor(Math.random() * 1e9)}`,
      createdAt: new Date().toISOString(),
      status: 'CONFIRMED',
      ...data,
      total: Number((data as any).total) || 0,
    };

    const all = this.read();
    all.unshift(item);
    localStorage.setItem(KEY, JSON.stringify(all));
    return item;
  }

  cancel(id: string): void {
    const all = this.read();
    const idx = all.findIndex(r => r.id === id);
    if (idx === -1) return;

    all[idx] = { ...all[idx], status: 'CANCELED' };
    localStorage.setItem(KEY, JSON.stringify(all));
  }

  // -----------------

  private assertCanBook(matricule: string, date?: string) {
    const user = this.userService.getByMatricule(matricule);

    // si on n'a pas le user, on laisse passer (dev local)
    if (!user) return;

    // pénalité active ?
    if (user.bookingBlockedUntil) {
      const today = new Date().toISOString().slice(0, 10);
      if (today < user.bookingBlockedUntil) {
        throw new Error(`Pénalité active jusqu’au ${user.bookingBlockedUntil}`);
      }
    }

    // date requise pour appliquer la règle
    if (!date) return;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const target = new Date(date);
    target.setHours(0, 0, 0, 0);

    const diffDays = Math.floor((target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

    // windows SGBD (max avance)
    const maxDays =
      user.memberCategory === 'GLOBAL' ? 21 :
        user.memberCategory === 'SITE' ? 14 :
          5;

    if (diffDays > maxDays) {
      throw new Error(`Tu ne peux réserver que ${maxDays} jours à l’avance avec ton type de membre.`);
    }

    // membre SITE : uniquement son site
    if (user.memberCategory === 'SITE' && user.homeSite) {
      // si tu passes siteName dans la réservation, tu peux bloquer ici
      // (pour l'instant on ne bloque pas si siteName n’est pas fourni)
    }
  }

  private read(): ReservationModel[] {
    try {
      const raw = localStorage.getItem(KEY);
      return raw ? (JSON.parse(raw) as ReservationModel[]) : [];
    } catch {
      return [];
    }
  }
}
