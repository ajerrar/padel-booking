﻿import { Injectable, signal } from '@angular/core';

const CURRENT_KEY = 'pb_current_user';
const USERS_KEY = 'pb_users';

export type Role = 'User' | 'AdminGlobal' | 'AdminClub';
export type MemberCategory = 'GLOBAL' | 'SITE' | 'FREE';

export interface UserModel {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;

  city: string;
  level: string;

  // ✅ SGBD
  memberCategory: MemberCategory;   // GLOBAL / SITE / FREE
  homeSite?: string;               // obligatoire si SITE (ex: "Waterloo")

  // ✅ pénalité : bloque les réservations jusque cette date (ISO)
  bookingBlockedUntil?: string;    // ex: "2026-03-10"

  matricule: string;               // Gxxxx / Sxxxxx / Lxxxxx / ADM-...
  role: Role;                      // User / AdminGlobal / AdminClub
}

@Injectable({ providedIn: 'root' })
export class UserService {
  currentUser = signal<UserModel | null>(this.readCurrent());

  register(payload: Omit<UserModel, 'id' | 'matricule'>): UserModel {
    const user: UserModel = {
      id: `${Date.now()}-${Math.floor(Math.random() * 1e9)}`,
      matricule: this.generateMatricule(payload.role, payload.memberCategory),
      ...payload,
    };

    this.saveUser(user);

    localStorage.setItem(CURRENT_KEY, JSON.stringify(user));
    this.currentUser.set(user);

    return user;
  }

  loginByEmail(email: string): UserModel | null {
    const users = this.getUsers();
    const u = users.find(x => String(x.email).toLowerCase() === String(email).toLowerCase());
    if (!u) return null;

    localStorage.setItem(CURRENT_KEY, JSON.stringify(u));
    this.currentUser.set(u);
    return u;
  }

  logout() {
    localStorage.removeItem(CURRENT_KEY);
    this.currentUser.set(null);
  }

  // ✅ utile pour les validations côté réservation
  getByMatricule(matricule: string): UserModel | null {
    const users = this.getUsers();
    return users.find(u => u.matricule === matricule) ?? null;
  }

  // ✅ appliquer pénalité (1 semaine) : bloque les réservations
  applyBookingPenalty(matricule: string, days = 7) {
    const users = this.getUsers();
    const idx = users.findIndex(u => u.matricule === matricule);
    if (idx === -1) return;

    const until = new Date();
    until.setDate(until.getDate() + days);

    users[idx] = {
      ...users[idx],
      bookingBlockedUntil: until.toISOString().slice(0, 10), // YYYY-MM-DD
    };

    localStorage.setItem(USERS_KEY, JSON.stringify(users));

    // si c'est le user courant, on refresh aussi
    const cur = this.currentUser();
    if (cur?.matricule === matricule) {
      this.currentUser.set(users[idx]);
      localStorage.setItem(CURRENT_KEY, JSON.stringify(users[idx]));
    }
  }

  // ✅ Seed admins
  seedAdmins() {
    const users = this.getUsers();

    const hasGlobal = users.some(u => u.role === 'AdminGlobal');
    const hasClub = users.some(u => u.role === 'AdminClub');

    if (!hasGlobal) {
      this.saveUser({
        id: 'seed-admin-global',
        firstName: 'Admin',
        lastName: 'Global',
        email: 'admin@padel.com',
        phone: '',
        city: 'Bruxelles',
        level: 'Avancé',
        memberCategory: 'GLOBAL',
        homeSite: '',
        matricule: 'ADM-GLOBAL',
        role: 'AdminGlobal',
      });
    }

    if (!hasClub) {
      this.saveUser({
        id: 'seed-admin-club',
        firstName: 'Admin',
        lastName: 'Site',
        email: 'site@padel.com',
        phone: '',
        city: 'Waterloo',
        level: 'Avancé',
        memberCategory: 'SITE',
        homeSite: 'Waterloo',
        matricule: 'ADM-SITE',
        role: 'AdminClub',
      });
    }
  }

  // -------- helpers --------

  private saveUser(u: UserModel) {
    const users = this.getUsers();
    const idx = users.findIndex(x => x.email.toLowerCase() === u.email.toLowerCase());
    if (idx >= 0) users[idx] = u;
    else users.push(u);

    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  }

  private getUsers(): UserModel[] {
    try {
      const raw = localStorage.getItem(USERS_KEY);
      return raw ? (JSON.parse(raw) as UserModel[]) : [];
    } catch {
      return [];
    }
  }

  private readCurrent(): UserModel | null {
    try {
      const raw = localStorage.getItem(CURRENT_KEY);
      return raw ? (JSON.parse(raw) as UserModel) : null;
    } catch {
      return null;
    }
  }

  private generateMatricule(role: Role, category: MemberCategory): string {
    // admins: matricules fixes
    if (role === 'AdminGlobal') return 'ADM-GLOBAL';
    if (role === 'AdminClub') return 'ADM-SITE';

    // users: selon cahier SGBD
    if (category === 'GLOBAL') {
      const n = Math.floor(Math.random() * 9000 + 1000); // 4 chiffres
      return `G${n}`; // Gxxxx
    }

    if (category === 'SITE') {
      const n = Math.floor(Math.random() * 90000 + 10000); // 5 chiffres
      return `S${n}`; // Sxxxxx
    }

    // FREE
    const n = Math.floor(Math.random() * 90000 + 10000); // 5 chiffres
    return `L${n}`; // Lxxxxx
  }
}
