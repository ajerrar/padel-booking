import { Routes } from '@angular/router';
import { Home } from './features/home/home';
import { TerrainDetail } from './features/booking/terrain-detail/terrain-detail';
import { TerrainCard } from './features/booking/terrain-card/terrain-card';
import { ReservationPage } from './features/booking/reservation/reservation';
import { PaymentPage } from './features/booking/payment/payment';
import { PaymentSuccessPage } from './features/booking/payment-success/payment-success';
import { RegisterPage } from './features/auth/register/register';
import { ProfilePage } from './features/profile/user/user';
import { MyReservationsPage } from './features/booking/my-reservations/my-reservations';
import { AdminSiteDashboardPage } from './features/admin/admin-site/admin-site';
import { AdminGlobalDashboardPage } from './features/admin/admin-global/admin-global';
import { authGuard } from './core/guards/auth.guard';
import { LoginPage } from './features/auth/login/login';
import { userRedirectGuard } from './core/guards/user-redirect.guard';
import { loginRedirectGuard } from './core/guards/login-redirect.guard';
import { PublicMatchesPage } from './features/matches/matches-publics/matches-publics';
import { MatchDetailPage } from './features/matches/match-detail/match-detail';
import { InvitationsPage } from './features/matches/invitations/invitations';
import { NotificationsPage } from './features/matches/notifications/notifications';
import { AdminMembersPage } from './features/admin/admin-members/admin-members';
import { AdminSiteMembersPage } from './features/admin/admin-site-members/admin-site-members';
import { roleGuard } from './core/guards/role.guard';

export const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },

  { path: 'home', component: Home },

  { path: 'terrain/:id', component: TerrainCard },
  { path: 'terrain/:clubId/court/:courtId', component: TerrainDetail },

  { path: 'reservation', component: ReservationPage, canActivate: [authGuard] },
  { path: 'payment', component: PaymentPage, canActivate: [authGuard] },
  { path: 'payment-success', component: PaymentSuccessPage, canActivate: [authGuard] },

  { path: 'register', component: RegisterPage },
  { path: 'login', component: LoginPage, canActivate: [loginRedirectGuard] },

  { path: 'user', component: ProfilePage, canActivate: [userRedirectGuard] },
  { path: 'my-reservations', component: MyReservationsPage, canActivate: [authGuard] },
  { path: 'invitations', component: InvitationsPage, canActivate: [authGuard] },
  { path: 'notifications', component: NotificationsPage, canActivate: [authGuard] },

  { path: 'admin-site', component: AdminSiteDashboardPage, canActivate: [authGuard, roleGuard(['AdminClub'])] },
  { path: 'admin-global', component: AdminGlobalDashboardPage, canActivate: [authGuard, roleGuard(['AdminGlobal'])] },

  { path: 'admin-members', component: AdminMembersPage, canActivate: [authGuard, roleGuard(['AdminGlobal'])] },
  { path: 'admin-site-members', component: AdminSiteMembersPage, canActivate: [authGuard, roleGuard(['AdminClub'])] },

  { path: 'matches-publics', component: PublicMatchesPage, canActivate: [authGuard] },
  { path: 'match/:id', component: MatchDetailPage, canActivate: [authGuard] },

  { path: '**', redirectTo: 'home' }
];
